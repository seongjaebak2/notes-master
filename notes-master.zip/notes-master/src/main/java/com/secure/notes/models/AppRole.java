package com.secure.notes.models;

//유저의 권한을 이넘으로 정의 (유저, 관리자)
public enum AppRole {
    ROLE_USER, ROLE_ADMIN
}
